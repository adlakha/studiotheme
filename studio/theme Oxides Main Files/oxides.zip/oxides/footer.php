<?php
oxides_edge_get_footer();
?>