<?php

//Get search HTML
add_action('oxides_edge_before_page_header', 'oxides_edge_get_search', 9);