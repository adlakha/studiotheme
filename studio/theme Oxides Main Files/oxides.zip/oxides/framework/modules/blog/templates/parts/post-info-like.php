<div class="edgtf-blog-like">
	<?php if( function_exists('oxides_edge_get_like') ) oxides_edge_get_like(); ?>
</div>