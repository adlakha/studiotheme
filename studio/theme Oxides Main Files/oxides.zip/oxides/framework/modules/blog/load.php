<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/blog/options-map/map.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/blog/blog-functions.php';