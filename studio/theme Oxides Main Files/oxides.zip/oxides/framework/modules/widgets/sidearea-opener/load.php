<?php

require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/widgets/sidearea-opener/side-area-opener.php';