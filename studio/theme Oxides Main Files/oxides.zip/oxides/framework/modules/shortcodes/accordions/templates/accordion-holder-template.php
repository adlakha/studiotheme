<div class="edgtf-accordion-holder clearfix <?php echo esc_attr($acc_class)?> ">
	<?php echo oxides_edge_remove_wpautop($content)?>
</div>