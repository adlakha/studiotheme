<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/socialshare/social-share-functions.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/socialshare/social-share.php';
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/socialshare/options-map/map.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/socialshare/custom-styles/custom-styles.php';