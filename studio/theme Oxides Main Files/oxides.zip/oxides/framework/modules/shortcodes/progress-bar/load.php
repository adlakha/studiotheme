<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/progress-bar/progress-bar.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/progress-bar/custom-styles/progress-bar.php';

