<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/pricing-table/pricing-tables.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/pricing-table/pricing-table.php';
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/pricing-table/options-map/map.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/pricing-table/custom-styles/custom-styles.php';