<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/input-fields/options-map/map.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/input-fields/custom-styles/custom-styles.php';