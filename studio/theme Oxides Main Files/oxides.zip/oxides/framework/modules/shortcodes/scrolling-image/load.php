<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/scrolling-image/scrolling-image.php';