<?php
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/carousel-with-image-and-text/carousel-with-image-and-text.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/carousel-with-image-and-text/cwiat-single.php';