<div class="edgtf-carousel-with-image-and-text">
	<div class="edgtf-carousel-with-image-and-text-slider" <?php echo oxides_edge_get_inline_attrs($slider_data); ?>>
        <?php echo oxides_edge_remove_wpautop($content) ?>
	</div>
</div>