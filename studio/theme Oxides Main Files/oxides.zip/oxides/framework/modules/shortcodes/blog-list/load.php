<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/blog-list/blog-list.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/blog-list/custom-styles/blog-list.php';