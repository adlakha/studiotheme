<div class="edgtf-portfolio-info-item">
    <h5 class="edgtf-portfolio-info-title"><?php the_title(); ?></h5>
    <div class="edgtf-portfolio-content">
        <?php the_content(); ?>
    </div>
</div>