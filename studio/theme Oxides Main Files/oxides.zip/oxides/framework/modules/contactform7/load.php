<?php

if (oxides_edge_contact_form_7_installed()) {
	include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/contactform7/options-map/map.php';
	include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/contactform7/custom-styles/contact-form.php';
	include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/contactform7/contact-form-7-config.php';
}